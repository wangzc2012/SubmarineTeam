import os
os.system('taskkill /f /im explorer.exe') #关闭任务栏