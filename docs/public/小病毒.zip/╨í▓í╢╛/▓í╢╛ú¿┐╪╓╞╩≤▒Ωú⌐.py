
from autopy import mouse
from tkinter import Tk
from random import randint

window = Tk()
window.withdraw()

width = window.winfo_screenwidth()
height = window.winfo_screenheight()

while True:
    try:
        mouseX = randint(0,width)
        mouseY = randint(0,height)

        mouse.move(mouseX,mouseY)
    except:
        pass
